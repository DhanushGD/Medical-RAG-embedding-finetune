import os
import sys
import json
import argparse
import pandas as pd
import numpy as np
import xgboost as xgb

def clean_term(val):
    if pd.isnull(val):
        return np.nan
    val_str = str(val).lower().strip()
    digits = ''.join(filter(str.isdigit, val_str))
    try:
        return int(digits) if digits else np.nan
    except ValueError:
        return np.nan

def clean_emp_length(val):
    if pd.isnull(val):
        return np.nan
    val_str = str(val).lower().strip()
    if '< 1 year' in val_str:
        return 0
    elif '10+ years' in val_str:
        return 10
    else:
        digits = ''.join(filter(str.isdigit, val_str))
        try:
            return int(digits) if digits else np.nan
        except ValueError:
            return np.nan

def clean_revol_util(val):
    if pd.isnull(val):
        return np.nan
    if isinstance(val, (int, float)):
        return float(val)
    val_str = str(val).replace('%', '').strip()
    try:
        return float(val_str)
    except ValueError:
        return np.nan

def preprocess_input(df_input, metadata):
    features = metadata['features']
    cat_maps = metadata['categorical_mappings']
    fills = metadata['default_fill_values']
    
    # Initialize empty DataFrame for processed features
    X = pd.DataFrame(index=df_input.index)
    
    # Process features one by one with fallback to NaN if missing
    
    # 1. loan_amnt
    X['loan_amnt'] = pd.to_numeric(df_input.get('loan_amnt', pd.Series(np.nan, index=df_input.index)), errors='coerce')
    
    # 2. term
    if 'term' in df_input.columns:
        X['term'] = df_input['term'].apply(clean_term)
    else:
        X['term'] = np.nan
        
    # 3. int_rate
    X['int_rate'] = pd.to_numeric(df_input.get('int_rate', pd.Series(np.nan, index=df_input.index)), errors='coerce')
    
    # 4. grade
    if 'grade' in df_input.columns:
        X['grade'] = df_input['grade'].map(cat_maps['grade'])
    else:
        X['grade'] = np.nan
        
    # 5. emp_length
    if 'emp_length' in df_input.columns:
        X['emp_length'] = df_input['emp_length'].apply(clean_emp_length)
    else:
        X['emp_length'] = np.nan
        
    # 6. home_ownership
    if 'home_ownership' in df_input.columns:
        # standardizing mapping
        X['home_ownership'] = df_input['home_ownership'].astype(str).str.upper().str.strip().map(cat_maps['home_ownership'])
    else:
        X['home_ownership'] = np.nan
        
    # 7. annual_inc
    X['annual_inc'] = pd.to_numeric(df_input.get('annual_inc', pd.Series(np.nan, index=df_input.index)), errors='coerce')
    
    # 8. verification_status
    if 'verification_status' in df_input.columns:
        # Standardizing mapping
        X['verification_status'] = df_input['verification_status'].astype(str).str.strip().map(cat_maps['verification_status'])
    else:
        X['verification_status'] = np.nan
        
    # 9. dti
    X['dti'] = pd.to_numeric(df_input.get('dti', pd.Series(np.nan, index=df_input.index)), errors='coerce')
    
    # 10. revol_bal
    X['revol_bal'] = pd.to_numeric(df_input.get('revol_bal', pd.Series(np.nan, index=df_input.index)), errors='coerce')
    
    # 11. revol_util
    if 'revol_util' in df_input.columns:
        X['revol_util'] = df_input['revol_util'].apply(clean_revol_util)
    else:
        X['revol_util'] = np.nan
        
    # 12. total_acc
    X['total_acc'] = pd.to_numeric(df_input.get('total_acc', pd.Series(np.nan, index=df_input.index)), errors='coerce')
    
    # Ensure correct columns and order
    X = X[features]
    
    # Fill missing values using training defaults
    for col in features:
        # If mapping returned NaN, fill it as well
        X[col] = X[col].fillna(fills[col])
        
    return X

def get_test_record():
    return {
        "loan_amnt": 12000,
        "term": " 36 months",
        "int_rate": 10.99,
        "grade": "B",
        "emp_length": "5 years",
        "home_ownership": "MORTGAGE",
        "annual_inc": 65000,
        "verification_status": "Source Verified",
        "dti": 16.5,
        "revol_bal": 9500,
        "revol_util": "40.5%",
        "total_acc": 18
    }

def main():
    parser = argparse.ArgumentParser(description="Multi-Agent Credit Model Risk Auditor - Inference Script")
    parser.add_argument('--input-json', type=str, help="Inline JSON string of loan application data (single dictionary or list of dictionaries)")
    parser.add_argument('--input-file', type=str, help="Path to input CSV or JSON file containing loan application data")
    parser.add_argument('--output', type=str, help="Path to save output predictions (as JSON)")
    
    args = parser.parse_args()

    # Load Model and Metadata
    model_path = 'model_artifacts/credit_model.json'
    metadata_path = 'model_artifacts/model_metadata.json'

    if not os.path.exists(model_path) or not os.path.exists(metadata_path):
        print(f"Error: Model artifacts not found. Please run 'train.py' first to train the model and save artifacts.")
        sys.exit(1)

    with open(metadata_path, 'r') as f:
        metadata = json.load(f)

    # Load trained XGBoost model
    model = xgb.XGBClassifier()
    model.load_model(model_path)

    # Determine Input Source
    data_loaded = False
    raw_data = None

    if args.input_json:
        try:
            raw_data = json.loads(args.input_json)
            # Ensure it is a list
            if isinstance(raw_data, dict):
                raw_data = [raw_data]
            df_input = pd.DataFrame(raw_data)
            data_loaded = True
            print(f"Loaded {len(df_input)} record(s) from inline JSON.")
        except Exception as e:
            print(f"Error parsing inline JSON: {e}")
            sys.exit(1)

    elif args.input_file:
        if not os.path.exists(args.input_file):
            print(f"Error: Input file '{args.input_file}' not found.")
            sys.exit(1)
        
        try:
            if args.input_file.endswith('.csv'):
                df_input = pd.read_csv(args.input_file)
            elif args.input_file.endswith('.json'):
                with open(args.input_file, 'r') as f:
                    file_data = json.load(f)
                if isinstance(file_data, dict):
                    file_data = [file_data]
                df_input = pd.DataFrame(file_data)
            else:
                print("Error: Unsupported file format. Please use a .csv or .json file.")
                sys.exit(1)
            data_loaded = True
            print(f"Loaded {len(df_input)} record(s) from '{args.input_file}'.")
        except Exception as e:
            print(f"Error reading input file: {e}")
            sys.exit(1)
            
    else:
        # Run demo mode with default mock record
        print("No input arguments provided. Running in Demo Mode with a sample loan application:")
        mock_record = get_test_record()
        print(json.dumps(mock_record, indent=4))
        df_input = pd.DataFrame([mock_record])
        data_loaded = True

    if not data_loaded or df_input.empty:
        print("Error: No valid data could be loaded for inference.")
        sys.exit(1)

    # Preprocess Data
    X = preprocess_input(df_input, metadata)

    # Predict
    probabilities = model.predict_proba(X)[:, 1]
    predictions = model.predict(X)

    # Format Results
    results = []
    for idx, row in df_input.iterrows():
        result = {
            "record_id": idx,
            "inputs": row.to_dict(),
            "preprocessed_features": X.iloc[idx].to_dict(),
            "default_probability": float(probabilities[idx]),
            "default_prediction": int(predictions[idx]),
            "credit_score_status": "High Risk (Default Predicted)" if predictions[idx] == 1 else "Approved / Low Risk"
        }
        results.append(result)

    # Print Results
    print("\n" + "="*50)
    print("INFERENCE RESULTS")
    print("="*50)
    print(json.dumps(results if len(results) > 1 else results[0], indent=4))
    print("="*50)

    # Save output if requested
    if args.output:
        try:
            with open(args.output, 'w') as f:
                json.dump(results, f, indent=4)
            print(f"Saved inference results to '{args.output}'.")
        except Exception as e:
            print(f"Error saving output: {e}")

if __name__ == "__main__":
    main()
