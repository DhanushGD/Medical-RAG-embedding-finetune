# Multi-Agent Credit Model Risk Auditor

An agentic AI system that automatically audits machine learning credit scoring models for performance degradation, data quality issues, and regulatory compliance gaps.

The system utilizes **Graph RAG** to query a regulatory knowledge graph (covering federal guidance like **SR 11-7** and **Basel III** rules) and uses **LangGraph** to coordinate multi-agent auditing pipelines that output structured, institutional-grade model validation reports.

---

## 📂 Current Directory Structure

- `Data/`
  - `loan.csv` (1.19 GB Lending Club dataset)
  - `LCDataDictionary.xlsx` (Data dictionary)
- `model_artifacts/` (Outputs generated during training)
  - `credit_model.json` (Trained XGBoost subject model)
  - `model_metadata.json` (Feature configurations, encoders, and imputation values)
  - `training_stats.json` (Reference decile distributions for drift calculation)
  - `shap_importances.json` (SHAP value feature importances for explainability)
  - `test_data.csv` (Standard test set)
  - `drifted_test_data.csv` (Drifted test set simulating economic downturn)
- `train.py` (Model training and validation pipeline)
- `inference.py` (Standalone credit scoring/prediction engine)

---

## 🚀 Step 1: Train the XGBoost Subject Model

We trained an XGBoost model on **150,000 credit records** using 12 standard credit features (including `loan_amnt`, `int_rate`, `grade`, `annual_inc`, `dti`, etc.).

### ⚠️ Intentional Real-World Flaws (Audit Anchors)
To give our auditing agents meaningful issues to identify and flag, we deliberately left in two critical real-world model risks:

1. **Class Imbalance (Recall Deficit)**: 
   - We trained the model on a natural **80:20 class ratio** (Good to Bad loans) **without adjusting weights** or upsampling. 
   - This results in a model with a high overall accuracy (~78%) but an extremely low default **Recall of 9%** when evaluated at a standard `0.5` threshold.
2. **Feature / Population Drift**:
   - We generated a `drifted_test_data.csv` simulating a severe macroeconomic downturn by artificially **reducing annual income by 35%** and **increasing DTI by 15%**.
   - Training reference statistics (including decile boundaries) are saved in `training_stats.json` to act as the baseline for the monitoring agents.

---

## 💻 Quick Start & Usage

### 1. Model Training & Asset Creation
To retrain the model, run SHAP analysis, and regenerate all auditing assets:
```bash
python train.py
```

### 2. Standalone Inference
Test single applicants or batch files using the trained model:

* **Demo Mode (Runs a default sample applicant)**:
  ```bash
  python inference.py
  ```
* **Custom Applicant JSON File**:
  Create a JSON file containing the raw inputs (such as the high-risk applicant in `high_risk.json`) and run:
  ```bash
  python inference.py --input-file "path/to/applicant.json"
  ```

---

## 🔮 Future Roadmap (Subsequent Steps)

The full **Multi-Agent Credit Model Risk Auditor** will construct the following subsequent modules:

```mermaid
graph TD
    A[XGBoost Subject Model & Stats] --> D[Agent Pipeline Orchestration]
    B[(Neo4j Regulatory Knowledge Graph)] --> C[Graph RAG Compliance Agent]
    C --> D
    D --> E[Performance Auditor Agent]
    D --> F[Data Drift / Quality Agent]
    D --> G[SHAP Explainability Agent]
    E & F & G --> H[Judge Agent]
    H --> I[Structured Audit Report]
```

### 1. Graph RAG & Neo4j Compliance Knowledge Graph
- We will parse federal model risk management guidance (like the Federal Reserve's **SR 11-7** and **Basel III** frameworks) into nodes (Requirements, Guidelines, Penalties) and relationships in **Neo4j**.
- A **Compliance Agent** will use Graph RAG (traversing the knowledge graph with Cypher queries rather than relying on basic vector searches) to find exactly which regulations apply to this model type.

### 2. LangGraph Multi-Agent Orchestrator
We will connect several specialist agents to automatically audit the model:
- 📊 **Performance Agent**: Evaluates accuracy metrics, flags the low 9% default recall, and recommends threshold calibration.
- 📉 **Data Drift Agent**: Computes the **Population Stability Index (PSI)** and **Kolmogorov-Smirnov (KS)** tests by comparing drifted production data against `training_stats.json`.
- 🔍 **Explainability Agent**: Ingests `shap_importances.json` and uses an LLM to explain the model's global and local decision boundaries.
- ⚖️ **Compliance & Judge Agent**: Resolves discrepancies, gathers evidence from Graph RAG, and compiles the final structured **Model Validation Report**.
