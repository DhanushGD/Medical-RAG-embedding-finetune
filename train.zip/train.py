import os
import json
import pandas as pd
import numpy as np
import xgboost as xgb
import shap
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score, accuracy_score

def clean_term(val):
    if pd.isnull(val):
        return np.nan
    val_str = str(val).lower().strip()
    # Extract numbers (e.g. ' 36 months' -> 36)
    digits = ''.join(filter(str.isdigit, val_str))
    try:
        return int(digits) if digits else np.nan
    except ValueError:
        return np.nan

def clean_emp_length(val):
    if pd.isnull(val):
        return np.nan
    val_str = str(val).lower().strip()
    if '< 1 year' in val_str:
        return 0
    elif '10+ years' in val_str:
        return 10
    else:
        # Extract digits
        digits = ''.join(filter(str.isdigit, val_str))
        try:
            return int(digits) if digits else np.nan
        except ValueError:
            return np.nan

def clean_revol_util(val):
    if pd.isnull(val):
        return np.nan
    if isinstance(val, (int, float)):
        return float(val)
    val_str = str(val).replace('%', '').strip()
    try:
        return float(val_str)
    except ValueError:
        return np.nan

def main():
    print("=" * 60)
    print("Step 1: Training XGBoost Credit Scoring Model")
    print("=" * 60)

    # 1. Load Data in Chunks (Optimized for 1.19 GB file)
    csv_path = 'Data/loan.csv'
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Lending Club dataset not found at {csv_path}. Please place loan.csv in the Data/ directory.")

    print(f"Reading and filtering dataset from '{csv_path}'...")
    chunksize = 50000
    chunks = []
    collected_rows = 0
    target_rows = 150000
    target_statuses = {'Fully Paid', 'Charged Off', 'Default'}

    for chunk in pd.read_csv(csv_path, chunksize=chunksize, low_memory=False):
        filtered_chunk = chunk[chunk['loan_status'].isin(target_statuses)]
        chunks.append(filtered_chunk)
        collected_rows += len(filtered_chunk)
        if collected_rows >= target_rows:
            print(f"Collected {collected_rows} finalized loans. Stopping data loading.")
            break

    # Consolidate and slice to exact target_rows
    df_raw = pd.concat(chunks, ignore_index=True).iloc[:target_rows]
    print(f"Final data shape for model building: {df_raw.shape}")

    # Define target
    # 0 = Fully Paid (Good), 1 = Charged Off / Default (Bad)
    df_raw['default'] = df_raw['loan_status'].apply(lambda x: 1 if x in {'Charged Off', 'Default'} else 0)

    # Select features
    features = [
        'loan_amnt', 'term', 'int_rate', 'grade', 'emp_length',
        'home_ownership', 'annual_inc', 'verification_status',
        'dti', 'revol_bal', 'revol_util', 'total_acc'
    ]
    
    # 2. Split into train and test raw sets first (to generate realistic test datasets)
    print("Splitting dataset into train (80%) and test (20%) sets...")
    df_train_raw, df_test_raw = train_test_split(df_raw, test_size=0.2, random_state=42, stratify=df_raw['default'])

    # 3. Dynamic Metadata Extraction & Training Preprocessing
    print("Preprocessing training data and computing imputation values...")
    
    # Define categorical mappings
    grade_map = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5, 'G': 6}
    home_ownership_map = {'MORTGAGE': 0, 'RENT': 1, 'OWN': 2, 'OTHER': 3, 'NONE': 3, 'ANY': 3}
    verification_status_map = {'Not Verified': 0, 'Source Verified': 1, 'Verified': 2}

    # Preprocess training features
    X_train = pd.DataFrame(index=df_train_raw.index)
    X_train['loan_amnt'] = pd.to_numeric(df_train_raw['loan_amnt'], errors='coerce')
    X_train['term'] = df_train_raw['term'].apply(clean_term)
    X_train['int_rate'] = pd.to_numeric(df_train_raw['int_rate'], errors='coerce')
    X_train['grade'] = df_train_raw['grade'].map(grade_map)
    X_train['emp_length'] = df_train_raw['emp_length'].apply(clean_emp_length)
    X_train['home_ownership'] = df_train_raw['home_ownership'].map(home_ownership_map)
    X_train['annual_inc'] = pd.to_numeric(df_train_raw['annual_inc'], errors='coerce')
    X_train['verification_status'] = df_train_raw['verification_status'].map(verification_status_map)
    X_train['dti'] = pd.to_numeric(df_train_raw['dti'], errors='coerce')
    X_train['revol_bal'] = pd.to_numeric(df_train_raw['revol_bal'], errors='coerce')
    X_train['revol_util'] = df_train_raw['revol_util'].apply(clean_revol_util)
    X_train['total_acc'] = pd.to_numeric(df_train_raw['total_acc'], errors='coerce')

    y_train = df_train_raw['default']

    # Compute default fill values (medians for numerical, modes for categorical) from training set
    default_fills = {}
    for col in X_train.columns:
        if col in ['grade', 'home_ownership', 'verification_status', 'term']:
            default_fills[col] = float(X_train[col].mode().iloc[0]) if not X_train[col].mode().empty else 0.0
        else:
            default_fills[col] = float(X_train[col].median())

    # Impute training values
    for col in X_train.columns:
        X_train[col] = X_train[col].fillna(default_fills[col])

    # Save Preprocessing Metadata
    os.makedirs('model_artifacts', exist_ok=True)
    metadata = {
        'features': features,
        'categorical_mappings': {
            'grade': grade_map,
            'home_ownership': home_ownership_map,
            'verification_status': verification_status_map
        },
        'default_fill_values': default_fills
    }
    with open('model_artifacts/model_metadata.json', 'w') as f:
        json.dump(metadata, f, indent=4)
    print("Saved 'model_artifacts/model_metadata.json'.")

    # 4. Preprocess Test Data
    X_test = pd.DataFrame(index=df_test_raw.index)
    X_test['loan_amnt'] = pd.to_numeric(df_test_raw['loan_amnt'], errors='coerce')
    X_test['term'] = df_test_raw['term'].apply(clean_term)
    X_test['int_rate'] = pd.to_numeric(df_test_raw['int_rate'], errors='coerce')
    X_test['grade'] = df_test_raw['grade'].map(grade_map)
    X_test['emp_length'] = df_test_raw['emp_length'].apply(clean_emp_length)
    X_test['home_ownership'] = df_test_raw['home_ownership'].map(home_ownership_map)
    X_test['annual_inc'] = pd.to_numeric(df_test_raw['annual_inc'], errors='coerce')
    X_test['verification_status'] = df_test_raw['verification_status'].map(verification_status_map)
    X_test['dti'] = pd.to_numeric(df_test_raw['dti'], errors='coerce')
    X_test['revol_bal'] = pd.to_numeric(df_test_raw['revol_bal'], errors='coerce')
    X_test['revol_util'] = df_test_raw['revol_util'].apply(clean_revol_util)
    X_test['total_acc'] = pd.to_numeric(df_test_raw['total_acc'], errors='coerce')
    
    y_test = df_test_raw['default']

    # Impute test values using training fill values
    for col in X_test.columns:
        X_test[col] = X_test[col].fillna(default_fills[col])

    # 5. Extract and Save Training Statistics (For Data Drift & Audit Agents)
    print("Extracting reference training statistics...")
    training_stats = {}
    for col in X_train.columns:
        col_data = X_train[col]
        stats = {
            'mean': float(col_data.mean()),
            'std': float(col_data.std()),
            'min': float(col_data.min()),
            'max': float(col_data.max()),
        }
        # Add deciles for PSI calculation
        deciles = np.percentile(col_data, np.arange(0, 101, 10))
        stats['deciles'] = deciles.tolist()
        
        # Categorical distribution proportions
        stats['proportions'] = col_data.value_counts(normalize=True).to_dict()
        training_stats[col] = stats
        
    with open('model_artifacts/training_stats.json', 'w') as f:
        json.dump(training_stats, f, indent=4)
    print("Saved 'model_artifacts/training_stats.json'.")

    # 6. Model Training (Deliberately keeping class imbalance)
    print("\nTraining XGBoost Classifier...")
    # Calculate imbalance ratio for logging (unweighted model)
    imbalance_ratio = (y_train == 0).sum() / (y_train == 1).sum()
    print(f"Training Class Distribution: Good={sum(y_train == 0)}, Bad={sum(y_train == 1)} (Ratio = {imbalance_ratio:.2f}:1)")
    print("Note: Imbalance is left unaddressed to provide meaningful auditing results.")

    model = xgb.XGBClassifier(
        n_estimators=100,
        max_depth=5,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        eval_metric='logloss'
    )
    model.fit(X_train, y_train)

    # 7. Model Evaluation
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    roc_auc = roc_auc_score(y_test, y_pred_proba)
    
    print("\n" + "="*40)
    print("MODEL EVALUATION RESULTS (On Standard Test Set)")
    print("="*40)
    print(f"Accuracy: {acc:.4f}")
    print(f"ROC AUC:  {roc_auc:.4f}")
    print("\nClassification Report:")
    report = classification_report(y_test, y_pred)
    print(report)
    print("="*40)

    # Save model
    model.save_model('model_artifacts/credit_model.json')
    print("Saved trained model to 'model_artifacts/credit_model.json'.")

    # 8. SHAP Explainability
    print("\nRunning SHAP analysis on a representative test sample...")
    # Sample 5000 records for fast but statistically accurate SHAP values
    X_test_sample = X_test.sample(min(5000, len(X_test)), random_state=42)
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_test_sample)

    # Calculate global feature importances (mean absolute SHAP)
    mean_abs_shap = np.abs(shap_values).mean(axis=0)
    shap_importance = dict(zip(X_train.columns.tolist(), mean_abs_shap.tolist()))
    # Sort descending
    shap_importance = dict(sorted(shap_importance.items(), key=lambda x: x[1], reverse=True))

    with open('model_artifacts/shap_importances.json', 'w') as f:
        json.dump(shap_importance, f, indent=4)
    print("Saved 'model_artifacts/shap_importances.json'.")

    # 9. Generate Standard and Drifted Test CSVs
    print("\nSaving test datasets for auditing and inference...")
    
    # Save standard test raw (including the default target for verification)
    test_cols_to_save = features + ['default']
    test_data_to_save = df_test_raw[test_cols_to_save].copy()
    test_data_to_save.to_csv('model_artifacts/test_data.csv', index=False)
    print(f"Saved baseline 'model_artifacts/test_data.csv' ({len(test_data_to_save)} rows).")

    # Save drifted test raw
    # Let's shift annual income down by 35% and dti up by 15% to simulate macroeconomic downturn
    drifted_test_data = df_test_raw[test_cols_to_save].copy()
    
    # Convert types to numeric before applying multiplier, then write back
    drifted_test_data['annual_inc'] = pd.to_numeric(drifted_test_data['annual_inc'], errors='coerce')
    drifted_test_data['dti'] = pd.to_numeric(drifted_test_data['dti'], errors='coerce')
    
    # Fill any nulls in income/dti before drift to ensure proper mathematical operations
    drifted_test_data['annual_inc'] = drifted_test_data['annual_inc'].fillna(default_fills['annual_inc'])
    drifted_test_data['dti'] = drifted_test_data['dti'].fillna(default_fills['dti'])
    
    drifted_test_data['annual_inc'] = drifted_test_data['annual_inc'] * 0.65
    drifted_test_data['dti'] = drifted_test_data['dti'] * 1.15
    
    drifted_test_data.to_csv('model_artifacts/drifted_test_data.csv', index=False)
    print(f"Saved drifted 'model_artifacts/drifted_test_data.csv' ({len(drifted_test_data)} rows).")
    print("Drift info: 'annual_inc' shifted by -35%, 'dti' shifted by +15%.")

    print("\nStep 1 successfully completed! All artifacts generated.")

if __name__ == "__main__":
    main()
